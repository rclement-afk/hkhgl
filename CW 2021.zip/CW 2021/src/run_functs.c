#include <kipr/botball.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/functions.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/consts.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/timer.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/threads.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/run_functs.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/clone_consts.h>
void god_start(){
  prime_or_clone();
  calibrate_gyro();
  thread_starting_pos();
 // wait_light();
  return grab_rings();
  //return ring_stand_return();
}

void grab_rings(){
   PID_gyro_drive(-200,1.2);
   slow_servo(arm, 1450,1);
   PID_gyro_drive(200,1.6); 
   slow_servo(claw,claw_min+250,1);
   PID_gyro_drive(-300,1);
   square_up(2,-400);
   /*
   Drive(-7545,-60); //7545
   slow_servo(arm,arm_max,1);
   turn_with_gyro(400,90,1); 
   //push square up
   Drive(3000,50);
   */
   /*
   square_up(2,400);
   PID_gyro_drive(-400,1);
   turn_with_gyro(400,-90);
   Drive(3000,50);
   turn_with_gyro(400,-90);
   PID_gyro_drive(-300,0.5);
   square_up(2,400);
   Drive(4000,50);
   slow_servo(shifter,shifter_hor,1);
   slow_servo(arm, arm_right, 1);
   slow_servo(claw,claw_max,1);
   slow_servo(arm, arm_middle, 1);
   slow_servo(
   */
   
}
void ring_stand_return(){
    
}

/*
red: 3 
orange: 3 5/8
yellow: 3 7/8
green: 4 1/8
blue: 4 4/8
*/