#include <kipr/botball.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/functions.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/consts.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/timer.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/run_functs.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/threads.h>
int main(){
    god_start();
    /*
    move(100,100);
    msleep(100);
    ring_stand_return();
    */
    
    
    return 0;
};
