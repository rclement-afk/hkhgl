//run functs
void god_start();
void grab_rings();
void ring_stand_return();