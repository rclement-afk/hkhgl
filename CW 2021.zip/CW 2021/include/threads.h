void starting_claw();
void thread_starting_pos();

void open_pom();
void thread_grab_pom();