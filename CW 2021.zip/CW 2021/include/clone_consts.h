int is_prime;
void prime_or_clone();