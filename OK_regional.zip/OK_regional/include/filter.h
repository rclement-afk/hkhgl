thread af_zero,af_one,af_two,af_three,af_three,af_four,af_five;

int filt_distribute;
float filter_out[6];
const int a_filter_ports[6];

void moving_win();
void csf_threads();
void kf_threads();
