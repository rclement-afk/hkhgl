void big_block();
void lift_arm_up();
void lower_arm();
void gyro();
void raise_arm();