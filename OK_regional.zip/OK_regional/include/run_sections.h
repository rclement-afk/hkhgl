int block_2andstack();
int water_contain();
int place_block_and_go();
int delivery();