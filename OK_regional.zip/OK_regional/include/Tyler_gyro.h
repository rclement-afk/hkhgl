float kp;// start adjusting this (smaller increments = more acurate)
float ki;
float kd;
float currentL;
float currentR;
float circ;

float integralActiveZone;
float errorL;
float errorR;
float errorTl;
float errorTr;
float lastErrorL;
float lastErrorR;
float proportionL;
float proportionR;
float integralL;
float integralR;
float derivativeL;
float derivativeR;